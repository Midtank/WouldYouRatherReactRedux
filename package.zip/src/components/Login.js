import React, {Component} from "react"
import {connect} from "react-redux"
import {setAuthedUser} from "../actions/authedUser"
import {Redirect, withRouter} from "react-router-dom"
class Login extends Component{

    
    logIn = (e) => {
        console.log("e.target.value: ", e.target.value)
        const {dispatch} = this.props
        dispatch(setAuthedUser(e.target.value))
        
    }

    
    render(){
        console.log("This.props.loggedIn: ", this.props.loggedIn)
        if(this.props.loggedIn){
            return <Redirect to="/"/>
        }
        return(
            <div>
                <h3 className = "center">LOGIN</h3>

                {Object.values(this.props.users).map((user) => (
                 
                    <div key={user.id}>
                    <img src = {user.avatarURL} alt={`Avatar of ${user.name}`} className="avatar" />
                    <input type="submit" value = {user.id} onClick = {this.logIn}/>
                    </div>
                )
                    )}
                
            </div>
        )
    }

}

function mapStateToProps({users, authedUser}){
    console.log("USERS: ", users)
    return{
        users,
        loggedIn: authedUser !== null
    }
}

export default withRouter(connect(mapStateToProps)(Login))