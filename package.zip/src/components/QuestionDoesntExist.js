import React, {Component} from "react"

class QuestionDoesntExist extends Component{
    render(){
        return(
            <div>
                <h3>404 error, the question does not exist</h3>
            </div>
        )
    }
}

export default QuestionDoesntExist