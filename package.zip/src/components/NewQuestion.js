import React, {Component} from "react"
import {connect} from "react-redux"
import {handleAddQuestion} from "../actions/questions"
import {Redirect} from "react-router-dom"
class NewQuestion extends Component{
    
    
    state = {
        text1: '',
        text2: "",
        toHome: false,
    }

    handleChange1 = (e) => {
        const text1 = e.target.value

        this.setState(() => ({
            text1
        }))
    }

    handleChange2 = (e) => {
        const text2 = e.target.value

        this.setState(() => ({
            text2
        }))
    }

    handleSubmit = (e) => {
        e.preventDefault()
        const {text1, text2} = this.state
        const {dispatch, id} = this.props
        const question = {
            optionOneText: text1,
            optionTwoText: text2,
        }
        dispatch(handleAddQuestion(question))
        
        this.setState(() => ({
            text1: "",
            text2:"",
            toHome: id ? false : true
        }))
    }
    
    render(){ 
        const {text1, text2, toHome} = this.state
        if(toHome){
            return<Redirect to="/" />
        }
        return(
           
            <div>
                <h3 className = "center">Would you rather...</h3>
                <form onSubmit = {this.handleSubmit}>
                    <h3>Option One: </h3>
                    <textarea
                    placeholder = "Enter the first option"
                    value = {text1}
                    onChange = {this.handleChange1}
                    className="textarea1"
                    maxLength = {100}
                    />
                    <h3>Option Two:</h3>
                    <textarea
                    placeholder = "Enter the second option"
                    value = {text2}
                    onChange = {this.handleChange2}
                    className="textarea2"
                    maxLength = {100}
                    />
                    <button className = "btn" type = "submit" disabled = {text1 === "" || text2 === ""}>Submit</button>
                </form>
            </div>
        )
    }

}
export default connect()(NewQuestion)