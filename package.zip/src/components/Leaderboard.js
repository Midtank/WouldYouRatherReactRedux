import React, {Component} from "react"
import {connect} from "react-redux"

class Leaderboard extends Component{
    render(){
        const {users} = this.props
        var listOfUsers = Object.values(users)
        console.log("List of users: ", listOfUsers)
        console.log("Leaderboard users: ", users)
        listOfUsers.map((user) => user.score = user.questions.length + Object.keys(user.answers).length)
        listOfUsers = listOfUsers.sort((a,b) => b.score - a.score) 
        return(
            <div>
                <h3>Leaderboard</h3>
                <ol>
                {listOfUsers.map((user) => (
                    <li key={user.id}>
                        <img src = {user.avatarURL} alt={`Avatar of ${user.name}`} className="avatar" />
                        <span>{user.name} aka {user.id}</span>
                        <p>Questions asked: {user.questions.length}</p>
                        <p>Questions answered: {Object.keys(user.answers).length}</p>
                    </li>

                ))}
                </ol>
                
            </div>
        )
    }

}

function mapStateToProps(users){
   return users
}

export default connect(mapStateToProps)(Leaderboard)