import React, {Component} from "react"
import {connect} from "react-redux"
import {Link, withRouter} from "react-router-dom"
class Question extends Component{

    render(){
        const { question, auth } = this.props

        if(question === null){
            return <p>This question doesn't exist</p>
        }

        const {
            id, timestamp, optionOne, optionTwo
        } = question

        return(
            <Link to={`/question/${id}`} className="question">
            <img src = {auth.avatarURL} alt={`Avatar of ${auth.name}`} className="avatar" />
           
            <div className = "question-info">
                <span>{auth.name}</span>
                <p>{formatDate(timestamp)}</p>
                <h3>Would you rather: </h3>
                <p>1: {optionOne.text}</p>
                <p>2: {optionTwo.text}</p>

            </div>
            </Link>
        )
    }
}

function formatDate (timestamp) {
    const d = new Date(timestamp)
    const time = d.toLocaleTimeString('en-US')
    return time.substr(0, 5) + time.slice(-2) + ' | ' + d.toLocaleDateString()
  }

function helperFormatQuestion(question){
    const {id, timestamp, author, optionOne, optionTwo} = question

    return {id, timestamp, author, optionOne, optionTwo}
}

function mapStateToProps({authedUser, users, questions}, {id} ){
    const question = questions[id]
    return{
        authedUser,
        question: question
        ? helperFormatQuestion(question)
            : null,
        auth: users[question.author]
    }
}

export default withRouter(connect(mapStateToProps)(Question))