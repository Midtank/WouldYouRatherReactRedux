import React, {Component} from "react"
import {connect} from "react-redux"
import Question from "./Question"
import { handleAnswerQuestion } from "../actions/questions";
import QuestionDoesntExist from "./QuestionDoesntExist"


class QuestionPage extends Component{
    //todo: need methods to handle choosing an option
handleOption1 = (e) => {
    e.preventDefault()
    const {dispatch} = this.props
    dispatch(handleAnswerQuestion(this.props.id, "optionOne"))
}

handleOption2 = (e) => {
    e.preventDefault()
    const {dispatch} = this.props
    dispatch(handleAnswerQuestion(this.props.id, "optionTwo"))
}
    render(){
        const {authedUser, question} = this.props
        if(question === undefined){
            return <QuestionDoesntExist />
        }
        const optionOneVotes = question.optionOne.votes.length
        const optionTwoVotes = question.optionTwo.votes.length
        const both = optionOneVotes + optionTwoVotes
        const chosenOption = question.optionOne.votes.filter((uid) => uid === authedUser ).length === 0 ? "Option Two" : "Option One"
        console.log("User hasn't answered question: ", (question.optionOne.votes.filter((uid) => uid === authedUser ).length === 0 
        && question.optionTwo.votes.filter((uid) => uid === authedUser ).length === 0) )
        return(
            <div>
                <Question id={this.props.id}/>
                 {
                (question.optionOne.votes.filter((uid) => uid === authedUser ).length === 0 
                && question.optionTwo.votes.filter((uid) => uid === authedUser ).length === 0) ?
                <div>
                
                
                <button className="btn" onClick = {(e) => this.handleOption1(e)}>Option 1</button>
                <button className = "btn"onClick = {(e) => this.handleOption2(e)}>Option 2</button>
                </div>:

                <div>
                    <p className = "active">{question.optionOne.text}</p><br/> <p>{optionOneVotes} vote(s) for this option</p> <p>{100 * optionOneVotes/both}%</p>
                    <br/>
                    <br/>
                    <br/>
                    <p className ="active">{question.optionTwo.text}</p><br/> <p>{optionTwoVotes} vote(s) for this option</p> <p>{100 *optionTwoVotes/both}%</p>
                    <br/><br/><br/>
                    <p>You answered {chosenOption}</p>
                </div>
                }
                
            </div>
        )
    }

}

function mapStateToProps({ authedUser, questions, users

}, props){
    const {id} = props.match.params
    const question = questions[id]
    
    return{
        id, users, authedUser, question
    }
}

export default connect(mapStateToProps)(QuestionPage)