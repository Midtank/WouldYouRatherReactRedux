import React, {Component} from "react"
import {connect} from "react-redux"
import Question from "./Question"
class Dashboard extends Component{

    setUnanswered= (e) =>{
        this.setState(() => ({
            showUnanswered: true}))
    }
    setAnswered = (e) =>{
        this.setState(() => ({
            showUnanswered: false}))
    }

    getUnanswered(){
        const {questions} = this.props
        console.log("The answered ids: " ,this.getAnswered())
        const authedUnanswered = Object.keys(questions).sort((a,b) => questions[b].timestamp - questions[a].timestamp).filter(
            function (answeredID){
                return this.indexOf(answeredID) < 0;
            }, this.getAnswered()
        )
        console.log("Unanswered ids: ", authedUnanswered)

        return authedUnanswered.sort((a,b) => b.timestamp - a.timestamp)
    }

    getAnswered(){
        const {users, authedUser, questions} = this.props
        const authedAnswered = users[authedUser].answers
        return Object.keys(authedAnswered).sort((a,b) => questions[b].timestamp - questions[a].timestamp)
    }

    state = {
        showUnanswered: true
    }
    render(){
        
        //Need to separate the two into answered, unanswered
        return(
            
            <div>
                <span className = "active">You are currently logged in as {this.props.authedUser}</span> <br/>
                <span textDecoration ="underline" onClick={this.setUnanswered}>UNANSWERED</span> <br/>
                <span textDecoration = "underline" onClick={this.setAnswered}>ANSWERED</span>
                <h3 className ="center">{this.state.showUnanswered ? "Unanswered Questions" : "Answered Questions"}</h3>
                <ul className = "dashboard-list">
                {this.state.showUnanswered ?
                this.getUnanswered().map((id) => (
                    <li key={id}>
                        <Question id ={id} />
                    </li>
                ))
                : this.getAnswered().map((id) => (
                    <li key={id}>
                        <Question id ={id} />
                    </li>
                ))}
                </ul> 
                
            </div>
        )
    }
}

//put this in separate methods
function mapStateToProps({questions, users, authedUser}){
    return {
        questions, users, authedUser
    }
}

export default connect(mapStateToProps)(Dashboard)