import {_saveQuestionAnswer, _saveQuestion} from "../utils/_DATA"
import { updateUsersAndQuestions } from "./shared";
export const RECEIVE_QUESTIONS = "RECEIVE_QUESTIONS"
export const ANSWER_QUESTION = "ANSWER_QUESTION"
export const ADD_QUESTION = "ADD_QUESTION"
export function receiveQuestions(questions){
    return {
        type: RECEIVE_QUESTIONS,
        questions
    }
}

export function handleAnswerQuestion(id, answer){
    
    return(dispatch, getState) => {
        
        const {authedUser} = getState()
        const qid = id
        console.log("The authedUser: ", authedUser)
        console.log("The questionId: ", id)
        console.log("The answer selected: ", answer)
        _saveQuestionAnswer({authedUser, qid, answer}).catch((e) => {
                console.warn("Error in handleAnswerQuestion")

        })
        dispatch(updateUsersAndQuestions())
    }
}

export function handleAddQuestion(question){
    
    return(dispatch, getState) => {
        const {authedUser} = getState()
        question = {
            ...question,
            author: authedUser
        }
        _saveQuestion(question).catch((e) => {
            console.warn("Error in handleAddQuestion")
        })
        dispatch(updateUsersAndQuestions())
    }

}

//todo: add methods for handling adding a question and asking a question