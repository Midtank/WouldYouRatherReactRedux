import { RECEIVE_QUESTIONS, ANSWER_QUESTION, ADD_QUESTION } from '../actions/questions'

export default function questions(state = {}, action) {
    switch (action.type) {
        case RECEIVE_QUESTIONS:
            return {
                ...state,
                ...action.questions
            }

        case ANSWER_QUESTION:

        console.log("State when Answer Question is clicked: ", state)
        
            switch (action.answer) {
                case "optionOne":

                return {
                    ...state,
                    [action.id]: {
                        ...state[action.id],
                        optionOne: {
                            ...state[action.id].optionOne,
                            votes: state[action.id].optionOne.votes.filter((uid) => uid === action.authedUser).length === 0
                            ? state[action.id].optionOne.votes.concat([action.authedUser]) : state[action.id].optionOne.votes
                        }
                    }
                }

                case "optionTwo":
                return {
                    ...state,
                    [action.id]: {
                        ...state[action.id],
                        optionTwo: {
                            ...state[action.id].optionTwo,
                            votes: state[action.id].optionTwo.votes.filter((uid) => uid === action.authedUser).length === 0
                            ? state[action.id].optionTwo.votes.concat([action.authedUser]) : state[action.id].optionTwo.votes
                        }
                    }
                }

                default:
                    return state

            }
        case ADD_QUESTION:
            return {
                ...state,
                [action.question.id]: action.question
            }
        default:
            return state
    }
}