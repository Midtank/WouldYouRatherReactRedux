let users = {
  sarahedo: {
    id: 'sarahedo',
    name: 'Sarah Edo',
    avatarURL: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUTEhIVFRUWFRgXFRcXFRUXFRUVFxUXFxUVFRUYHSggGBolHRUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGisdHx8tLSstLS0tLS0tLS0tLS0tLS0tLS0tKy0tLS0tLS0tLS0tLS0tLS0tLS0tNy0tLS0tK//AABEIAMIBAwMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAEBQACAwYBB//EADwQAAEDAgMFBQYFAwQDAQAAAAEAAhEDIQQSMQVBUWFxBiIygZETQqGxwfAUI1LR4QdiciQzsvGCktIV/8QAGgEAAwEBAQEAAAAAAAAAAAAAAQIDAAQFBv/EACURAAICAgMBAAICAwEAAAAAAAABAhEDIQQSMUETIjJRYYGhBf/aAAwDAQACEQMRAD8ASgwHc/mt6TZPqhPdHW6Nwuk8kzQUz00ySLxp8JleHX74IgD76D+VhUs7kfgjELOf206avQBKn6pntp35p6D5BK6guk+ilBh3PPdG+PVYbQwrqby1wgjVOtm1Rkc33gQ4eW5Y9qKwqVi8aEN/4hL9DQt2awEmeCZNw3JBbJHePRNKroCqvBTBwhCVH8FtVdIWKxjBjbqrmLYBZuasYyIVCxbubdTKgwg4avCFvlXhagYwBWq9LVAEUA9YLo2kELTF0Zh0TGj2q9PVeP0WjWqsfAG1LQrWnuVaQsVenuTGJU0KEIsja41QankGRQKzWKysEIGkUKIdTlqzyq2Ia4iAYVUKK45L1eAHioohOle7Qbkww+8cgl73zblPxRmCP0+SWQyDHcev0WGJYSe6Yv8AvZavdp1H/JZueJnkfqsgs5rad6jp1n6BL36pjtC9R/UpdHeSoVm2zKrW1Wl+m/0QuMaMzo0kx9E2w3Z59ag6vTOYsdBZviJkJViBZL9CVwFTK4nkjBUzIDCC6OaFaPgpi42815k16Lzd5rQ6HoizGCoVYFVhK2kY8K9hXZh3nRp9CrGg4aiFNzT8Y1GWVeZFq1q8hCwGWRQU1otMNTLntbxcB6lZypNmSHGE7K1HMa4vawuGZrTMlu4nggcTgn0XZXiD8COIK7PtE72dZhGga0elkw2zsptfDknUDM0+Ux5rghzpRmu+1L/hZwVaPnYutwFnh23M7lswXXso5zWkLFa09FWloVZmicxXFCx6IJH4wd09EuaCpzCiE3RDW2QzkypN7oWxozMAt3UpCq4LSVVIAjDYUWjxc9T816p0jD7fpNrcr6o/BNgeZ9AEJTHi8h8PndM9nslzAB7x/lRkyiMa7SSANZb81TFUiwhpjNFwN19DzRVbFijmy3foHfpH9vPmldGS7MeP1CC9MxTjmEPJ4pcPEnmKIc2DbfPNJAO8i1Qgy2FtZ1Cob911nD6qnaWg1tQ5dCJ9QlVU381qSS2/kpjWZYGnJPRFs0VNni56KzFReClC2y8IJMASvTpA4r6B2S7OCmBVqj8wiWg+4P8A6+S5uXy48eNv34h4QchNsXsU94Dq5LAfdHi8+C6jC7DoUrMpt6kSfUp+5oAQxZK+Zz8zLle3/pHSoJAvswNFlVawg5gDGsx9UJtXa4bLKd3aTwvFvRKfw1R0uc654lUx4J1cnQrYTtHYVCpPcDDxbb4aLj9qbHfRJOreI+vBdO1j6dw+eIVnYprrOH7L0MGWePV2ickmcFlunXZfAGrXafdYczj00+KYV+y2Z2anUaGnjMjpxTR7qeEpZKdyfETq4/sunJyYzj1htsEYfWTbO1Mrohp6gGPVJMbt2q8ZQ60RawSzG4gvN17QbZdGHiQik2tglN+FqTVZmq1ayyoxq9CJM0YbLWmLKlNtlrTFk4DPG6IE6o/GNlp6IBqSXoUVe1M6YgDol7xZGe2FhyTQAz2qN68c5Wch6taBomZgKo256qLwvm6ilZjoaDC4hovLvjNgneKxH4ZmQQahnP8A2j9IPzWeGo/hmSbVnDSx9mDu/wA734BJMRWaXd51je83/hRY6JmzEn5oqiyXHkJ9LrNlKSHTbjuW5eA2oRfun5FBehoWbTHckbzJ80kA7xTGpUdlykc0vd+6ZimLxfzRFXQoZ+5as0UzFsG6Cei0ZdYUhJhbUeAVIvQGjouxeyfa1faOEtpnyLtw8tfRfQwVz2walPD0GscYcZc6LmTu9IW7+01NphrSee5fLcyOXkZnJLS8OqFRR0Ap7yk/abH5WZGGCRchSjtgVZ3cko240uFkvHwqM9jSetCbCO706lO2YV7onU6AXPoEs2bhyHZj7oJ9Ef2nNajWY1jy0Brbglpe4jvOtreRG6Oa9H8feXokYmONoVGeJj2ji5pCXCi9xiPNdXjcealFgcSXx3yRHrc3WexMFnOeIYBDT+o8RyS5ckMK0FQsVYXDVGjlwSvbFF2q7ivQCS7Sw4gqPH5H73RpxpHDPYt6LbLbE4eDO5Sm2y+ihLsrRyv0sCqMUhaFmiqjMjdFqBopk0W+XvDknQAPFu7pCDYyyY49tnIGEkvQozfvWmHeI5qlQXWEkGyydGYwKoaYOqGZjDNxK1/EDgQntMANUFyoqVaoJKimE6LH4nNMk7yUx7QNa6nhqIADjTaZjQRJXP1Xd08ymfaHEltWnGraNP8A4iylJbQ68KUKIpOLbugXk2nkFjUqwXdL/sF5h8V7V3dbAGs3uiGYcAEm5n7gIpAFFYpdV3pliNUtrjVBfTMxeVqwWV8Ls6tVBNOm5wGsDRePpubZwIPNT7JugUzzDDvJpsPDF7yQJjd1S3CC56Lo+yDv9ziAPmVPkTccTaGirYdXpNpwJJdw4ckDXw79cpA6FdJsfBe1e90WYxz3GLwAYa3mYS7Y20nOq5atNhZfxNkgbsrolcGODast1sz7PUznvvXXV8E0iAFNh7Lpn83QHwt3AcU3r1mNFl5+XeS0x4qlRytfBtab+YWzgXRNS27NJjpJhD7cxgAN7rmqu24GXeuiGCc1aYHOtHaYfZFMmXEv5GMv/qPqmrmwFwWxdtPa7K4mN37Jli+0Tm2IK5p8WblT2FTHldKseQQUpdtxzlQ4su1XRi43V7ElOwGuy5CCLYsmr6c3QuIp2lerxsnWXV/SLQI1XgwFGhauHdC9FC0R2gV6TpcFcNspRHeCYBjjbtcgqeiPxze69L6Zsll6FHtRqDqshG5kNiClszAn1IKPo1muEFKK1MlyMpNgIJgK1GCTCioFExh/+HztI0O6fkr7dpvfUlrS4ZWgEDg0BECqRbdzgrSjixLQAJnyJ6FQc/o9GOzWClTynxEyfQrZ77Loe1NHD0xZga+wMQBN7gDT+CuXHeAi4CZGFtfU/fFK6upTSrqUtqalEVnb9lS4YVpYYOdxMbzMX8gEw2jhqVVuaowTv/gpT/T7GsIfReQDOdvMRBj0Cy7T7XaXlrD3W8N5Xh/im88kjocl1Rqzs9hpkPcOQI/ZH7PwFBktojvOFyTJK4tmOe6bkW4pv2Ic52Mp3Ju4nyaVXk4ciwyk5XSsSMlfh2WDe6hJBDSRBkTb7KGo7P8AaE5W5GEy5wAaXdAurGGB3Jbt2t7NkDWV4+Pkzn+qOl6QK/Gtp92QABAHIJPtDb4Fm3K57aeHxFWqQ0OO8AcDor09gYtol1J3w+i9CGDHGu0k2S7MyxuKc+SSljcOSbp3hdjV6hytpu6kEAdSV12C7KsogOf3nfAHkFefJjjVIVRb2INjbEJh77DcE+xWQiHAEcwia53BLsVh3O97KPUrhcu8u0nQ10qQuxOCoHwnKZ0VaOxqmYt4JlgsFRpuDoLnAyC46HiBotn4780X1BCf80nqHz+xWl9Fz8BlF0srM1Cf459kiqldWObaTZNixoW3uqtQd4qxHdXuY5XGxWbsu09FSibhWpmxVaWoVAGeO0f0S+mLJhj9HdEA028krMj1rUJXHeRrCg6/iCRhoGAutFl7xWsIoUzcAvV4WheoGGv4opvsCk0f6mo3usIyjc58i3Qa+i5/BeE9UTiK7yAC4wBYbgptJjoI27jfavJECQPsJdSLgY4rwtB1CLw2HGt/VD6Awr7+qX1Ewranql9VUAwYvIdIMdFrM6rHLJRdTDPZ4mkKT9CeYbf0XT/05H+rB4Mf8lzGH1PROux2L9niqZNplv8A7D94XPzIuXGml/QYfyR9YxOLDASuH2htB2JrNpt0LgJ87lGdpsU6MomEt7NNaxz6z7BogT+p38T6rw8GJQw9n6dEpW6O4pUmiANBZFQIKWYeo5wBIIB0nU+S3FWFw6T9tjuQdROQaITF1i7xG3ALGtizxS6tiVVKxHJmlesBol9XELOvXSyvVJXZhw/WTkwqpiwg21peDzWEFesF13KKS0KxnjK8hLHlbOdKHqlb/AAavSDhB+GoQL31WW8Y+NkwCq8Lpw5XH3wU8wGMa8EaOjQrVqT7Qp5SHibawiKO0hbMF6KmgB+MEtPRLgPkjK+KY4WO5abPwIdd2nBDJNR2xoxsCCBxBuEz2zUa2o1rdMt0sxIuEIvsrNLQMfEt2LGLrdjkaEL5Aovcyi1GL4PTzRZYhMDoOqPhTY6BHNgovDalULCT6q1IXKyMwarvS2qUxrHVCYbB1KrslNhc47gJKa6QpNjMHtMztGCfPQJm5uYknRa7b2DUwdNjKhGerlcQNQJMA+hRVDDCBOgHrAXNKX0rFCduzDJIsOf0RLdmin3yT3SDG+dyaub32ggAaydLaBU27XDWGOCVzb0N1S2ddQotrMZUFw5od6hMMLRZSHdaBOvVJeyzntwzWu90loOkxrI6ym3tJlfLZ1JScL0mOmWr1ggKldVrSEK4FbHjVGs1qVkK4koyhQJF1Z+FhXUkjVYuNElDPwB1XQMojesMSQ1Wx532pAcUc7WoFuqzlEY2vmMBCyvQ7aIkc6Fg90qlWpJUWRiNXrgqtWiuloAFtCPZu6JLwTfa4hp8h6kfsljhbRda1FICPS/RdBsuv3VzZTDZtcg8kk1aKRdB20MKKlSZiGj1kobEbOqO8IzRwR5dLnRpYfAfuu+2HsgUaQLh33QXSNOU+iupKEEI9yPj9Wm5phwI6hXYvre09mUawIqNH1HOVw22+zDqUvpy5o3RcD6haM1IVoQgqLwqJzBGD8IRZfCDwggBbVXKT9GNadS6gdf74IQOTnszsh+Lqim3TVx4NtJWulbMe9n+z1XGPysENHiduH8r612e7PUMI2KbRmi7z4jumdw5I7ZuzqeHYKdNoa0ep5lVq4gB0azHquTJkcxkj5v/AFOoOOOpGZBpggcILh9D6pLUJmBJgCY0v/0F0nbx2bE0uLafzcYSWkS0OnXUItjpAmMpuBz1CMsgW4STlHU5fRDbS77mgkBpe0EamJE2RWJpTlzAk8CbeQ4oLHuEWGUBwk62Gp1ujH00vDv9kUGvpPa2Qc5dJiJkiQRbkVjTrG7TYixCrsas8VaYIbDmAGLZRAgZeZla9pME4fmM8Q1HELwORj65nF/djJ6LCCr06ISHDbXGjrHgU1pYwESCoyxzgZNDNtIAIavVAWT8ZbVJdoY3gnw4HN7M5UH1seBvSfF4suOqFNQnVUe6F6OPDGBJyssShK9WFK1fgsWtm5V6Ae0hvKuV6Vk9yNGPcy2BshmlaiNCYG8rpxR7OhXoB2o6cvXTlFil2p5LWtWlzid5MdNyxC6ZMKI5H0qUQUPh6MmUxiynJjI6bsPs32lQvI7rDPV2jR8JXfV33tu+/LiuV7EE/hzuio6/KBr5rpQyxHHz1+QSydsUwrssleIdE3/lN3ttxSvGU5TRRmxJV2XRcSSxsnkoiSeP1/deK4lnB0V7iHaLOkY+CriCplCMEmBqdF9u7E7BGEw4zD8x4Dqh4SLN8vmuC/pjsL21b2zx3KUEc37h5a+i+t1H68lDI70ZHtRyBra2/Y9VK9fcd6GdX/6SdQnA9sMR/q6jmiYDW+jBPxJSfC1i6HTJIn+0IvtaAcRVEwM2nEQLFYlgOW9i2IECAUR0DVKhfkIMm/RvNCPw0tIe6QPidUXVaA8Nb3R4QeQF1Sq9uYsaJiAN8uTeGaHuw67fY03TOWQ8E+ESXMPo1dk54rUw4cFw3ZNv5j6JGb2jLngGyYjjcei6PZNV9FxY49y0SZm0DQfAcAuD/wBDj912XoIuhZtbYwfNoK5yq2rRO8hfSsZhpuEoxOCBsQvMxcmUP1ltDuKZyDNru0WbsRJklMNpbAIk0/Rc/WJaYcIXp4pQkv1JNP6GvrLGpVlCmqvM5VqFo3BWjXLBpVgVgmznLJRR1tLngnhjcnSA2WFiOJ0We0H5WQCJdrxAuiGNDBmedPhyCTYmvJJOpNum5egorHGl6KtmRvbgoRdeUhC0ZcylYyDsMBAKJzW0ug6J1CJqGACOF/JSa2OdN2JxeXuuNnzA5g6fNdtRqzvn0XzDZFQtDHcHT8V39OuHCRoRryVckKpkkwyu+d6X4py3LkNiHSFoozACQOKio7XT5rxVoU+fNd9PkicDgHV6rKTNXGOnNLsJUkL67/Tvs57KkK9Rp9pU8PJn0JXNOVFaOl2DspmFoNpN90XPF28rarVv5LSu+/kfglmIqFRSsxH1R6oStW1jcs31NOqk6KlGOC7RyMVUBvmd3R1aD9UMKgAJDBmMXv5x8kT2kflxdQgXIaG+bW6IRzgCM27dzhKyi8Nm4eWlx1j05BBPIBaGGMozuOsngmlfEMZTJnUQBz5ICvhy0ZWa+zlx4XCAWXw+INOoyoCQ7MHGNQ2b24RuX0ja2z6deiK1OQyM4AEE5tPPW3kvlgpkBky6o7n7o4r6N2C7QB1P8LVu5oPszuc2CS0W1Eb9fJLLwU82ZtIMIo1O7mPdndJNugkCeRTqpgZWOJ2WaghgaO8XFzvFeJjyJ+CXtx1Wi4zLgCZnfFhHx+C87PxO77QGUg1+zkn2vsFlUXEHinI23TIkmFSvjmakhcX48sHaTTHtM+abT7P1aJJALm8QlYK+tmsw2JCT7V2NhHzJDXTu1JGq7sOectSiyUoL4cAwrWmJMBdAez9Ntg7PJjfYX/dvot39mKju9IggeERxmxXfCCe2I0c2JmGjqiqNEAyUz/8Aw3tngN6T7beWjKD1jgvQUoRWhOrYv2pjc5yt8I+J4pY9177lrUywCNZ0XuXWRHIpO1uxqM2tMDmiWMgKtKmXEDgiWUTElK2EthxCzrzlN9PqtxaELiiYdbh8EEYb7NH5TZ4fVdDsTGR3CeiQYM9xn+I+SIa+CCNy7HG4kr2dgyqTM8fgfsqVncfL7+Cw2fiA9oO9bPYdTzt1+5XN4xwNyihf9wVFTsKc1/TfYAxVYF4Ps6cOdwPBvmvtftQBFrJZ2a2Q3C0GUmgAxLzxdvKOIElee5dmV8B8Y826JTjX31THFOSPaFaCVSCFYO5/39+SjsQAdUA7EBL8VjI3roUGwWLtuwcS55/SI6wEAyiHkuLoaIBvcm8j5I7EQ6oHyTNo4GNfglzKID70wYuLkydByAXO/Sq8NqtOiMzzcNHdHOP+kOK7rOkuL294fpF4XuIpuazL3bGXQdbzlHLcvKLs0EtMEG2gnddAzJSa8MNSbRAnxRoI4IulXIczI5zS2DmFjm1EIbI5wMmwMDhZEVKUvEmwaPkEKGPoOwe1jCwMr9185S+2U/3HgnTsFTqtJ1G4g2iQbRbUL4/g8RLuRmOg3nqm+xe1b6AGUy3N3gfCTy4FL0+oXR2uN2SMxOpiGnpqYH3ZD1th6Fg/ymYPHKNxF032XjaeIaKjHzIg8Wne1w4ovIA2Ji9jxsT99FtgOcpbHAEiHESe9F/u3otxgWukgATrGsz3usyPRNaNAQYdM2sdL6KOpZJJMD4TBWVmFtKlSpNLjAA94m3WT5JNj+1VJsNpiZ0J8IgQbark+0PaA1ahgxTb4BuPOOJSnDYruEwSZzEi8DRVUNGtDjae26r8wcTpLTEC3ILn6lVzpItIuDe/Lkj2YyWljwb+Ab4OiydVALDBEWJI/t0Rox4KjBSEiDCpiWXaXC4bJ5zotqNFpfm3QdbjRDUm5i7MTyPJBGNMPAILnXIzeu5TDCQ7vXBNuSvQpHKBIAjfqFpQDiyIbAsDETzlawnrCAG3BkIHEmAZ1n5othyjw+HxHqhtpiD9+XzToVjPCHuN/wAR8lu0oDBYjutngjGuXfF6IMabGxWR8biupdEAyuGa+IK6rCY8Opj4qGWG7QyZ44X0+/RRDuuZkqIUY+mDxKlX6L1RedDwsxXi1zm0NFFF0wEYkqfRKa+qii7YCMErnu+a9xBt/wCP7qKLhl/JnRHwxZ7vULZ3udVFEgTXEnuj73oOsbu/xH0XqiLMxc8wLfpC13ef0CiiqiTLU9CvGVnB0BxANiASARwI3r1RBmR0v9P6zhinNDiGljyWgkNJEQSNJSrtFjKjqrw6o9wBMAucQPUqKJY+hZz2INkd2VE1XT+n6hRRXgIEVf8Ae6THTM1b4/RvVRRRfrKrw8xNm2Qg0HVRRKY22pr/AOJ+a3w/+0FFEDfRbiXGX33LOr4D5fJRRVQsjbD+BvRNGKKLqx+EWWTPZRsVFE8/4gQcoooucof/2Q==",
    answers: {
      "8xf0y6ziyjabvozdd253nd": 'optionOne',
      "6ni6ok3ym7mf1p33lnez": 'optionTwo',
      "am8ehyc8byjqgar0jgpub9": 'optionTwo',
      "loxhs1bqm25b708cmbf3g": 'optionTwo'
    },
    questions: ['8xf0y6ziyjabvozdd253nd', 'am8ehyc8byjqgar0jgpub9']
  },
  tylermcginnis: {
    id: 'tylermcginnis',
    name: 'Tyler McGinnis',
    avatarURL: "https://pbs.twimg.com/profile_images/1059579226431676417/C235z-X5_400x400.jpg",
    answers: {
      "vthrdm985a262al8qx3do": 'optionOne',
      "xj352vofupe1dqz9emx13r": 'optionTwo',
    },
    questions: ['loxhs1bqm25b708cmbf3g', 'vthrdm985a262al8qx3do'],
  },
  johndoe: {
    id: 'johndoe',
    name: 'John Doe',
    avatarURL: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIQEhUQEhAQEA8QEBAQDxAPDw8QDxAPFhEWFhUVFRUYHSggGBolHRUVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGhAQGi0lHyAtLS4tLS0tLS0tLS0uLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSstLSstLf/AABEIALcBEwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAAAQIDBAUGBwj/xABEEAABBAEBBQYDBQQHBwUAAAABAAIDEQQhBRIxQVEGEyJhcYEUQqEyUpGx0SNicsEHFSQzkrLCQ2N0orPh8ERTVHOC/8QAGwEAAgMBAQEAAAAAAAAAAAAAAAECBAUDBgf/xAAtEQACAgEDAwIFAwUAAAAAAAAAAQIRAwQSIQUTMUFRFCIyYXFSsfAVM0LB0f/aAAwDAQACEQMRAD8A49CW0lL3h5gEJaQEWAgQltBQAiEtJEACEIQAIQlCAESlFJj5QNL16DilKSirY0m3SHIVLK2gGaULvheo9R/3VdmaXWXHw8KGgWbm6rhh9PJexdPyT88Gqq2RlFo8LQa5kmj6BUJ80AAAUBr+qz5stx58ln5+qzmqgqLuLp0IO5OzWGXM6qDAXAkAN5BSMkyKssYR6AHry9VhR7QeDd8OCmGe+rsir/KlS+Kz3e9lr4fDVbTo2nlpYrnacuf2ZlODxZsOOvuugXoen6mWfH83lGLrcCxT+XwwQlRS0CmIhCEmAIQhCAEIQiwCkickTAAhCEACEtoSsAQkQihWCEpQnQgpCChFDsLSIS0ihCJQkSoACEgS2kSGQ5ORu6WN48L0AA4uPkueyco77i0k61Z0J9enoos3KL5HOBNE6a8hwTL66dGj+Z6rzGu1bzTaX0o9BpNOsUbflk8DC7j+g/BbmxtgS5RqMeFv2nONNB6X1WVgEXqaHRer9ny1kMTWgDwhxrm46klY+ebiuDTwwUnyc7N/R3ORYfDfm54/0qtN/R3lgaNjd5NkH86Xp2NJvaWp25ABon6FVVmn7lzsQPE9p9kZ4hbo3MPm07v+IaLFk2e9unH0X0cclvC/xGiz59jY0hLjjwkni4MAJ9aU1qZLyQlpU/B4TsjGO/Z5LfXe7d7Lw9050MbY5G+KmWA4DiK6rgivW9EywyYXt83yeZ6tinjyrd49ASpqLWzRk2BQgJSmAAJU20qVBYiAlISBAxaSJUiBChKmpyBghNQihWCcU1KCpCCkWi0iQDklItCABCLQgACVJaCmABVdqP3Ynnnu1+JpWVl9oZKjA+88fQWuGpnsxSf2O2njuyxX3OeCUJLSgLxx6Utw8vqvSeyWSJIWi7dH4Xfy+i83woHPIa3VziAB5ngvUdgbMGLHu8XGi89Xfoqupaqi5p07s2oc0M+Vz3E0xjPtPd0H6q1Nl5oFthx7+4ZCXDyvQLIx5RG4yH7RG42/lBOteuibm7QYBZe4n9wmh6lcIxVWy2WZu1skR3Z8bcvrvNB/hdq0nytbWysuPIaXRlzaNObpoatcfBtzeBYbkZerX6j6re2FK2NpMcYY0neIaDqTzKjOvFDinfk1cqWIHu3TNY+r3S4BxB4aLzbb2MI53tBBaTvNI1BB1Wxt6GPIl3nPfY0MbXNa1x5Heqx09llbXgYxrN2Puz4gQHOdY0o2T6rW6Hl2ahJf5GV1jG54XL9JmBCLRa9oeRCkqS0IAAlTUpKYBaCEUhACIKEpQAicmpyABCS0IAWkUnbqKUbENpG6nUlpFgM3UAJ9JEWA2kUn0ikBYykJ9IpFgR0snbmO+QxRsaXve4hrRxJpbK0+zOMH5Lb+13Uwb6+G/papdRlWmm17FzQLdqIL7nLt7EZTmksdjyPaLdFHO10g8uFX7rEnxXxHde1zHcC1wIP1Xr42bEI3y33LmOtrmiiK48FgbYIyo/E2n7t+IU4HkvEx1Lvk9hPTRS4OZ7GR3ksvzI9QF6nEy15Z2Wfu5MfqR7kFemYmRqo6j6g0/glzNjGQHUDjQ81T2BgwxytMzC4A6h7HP9gBoef4ro8WcLRjgadaF+i5xlR3lDcYR2LA6Vz42FjCLAIoXpp6cfRX44mNtjRTSK9NFcy3tY1ZTpiSABpfFQkzolRgQdkXuMv7QiSNjnRmnbpAqgT1dZr+Ermc6dz6DvtNFG16jtHDDmi+lLzbbuN3c72dKr0pbnQlGWo58pGJ1rdHBx4bM6kUnIXsbPKDKSp1JCEgG0kTkJgNShOpFIsBpRSdSSkAIEFKhMBKQlQgCWktJaRS52QGkJE+km6ixjaRSchFhY1LSVFJ2IanIpLSLHY2lJjZvw8kc/KKRpf/APWfC/6En2TaUWTCHtcw/M0j8QuWaHcxyh7o6YcnbyRl7M9AwWtc18ZIduyufx+1G4Atd6LGz4KcbGjrp1aBcjsjtP3Q+GnaXblxxyg+MNv7LuoXR5O3oTH4H/JusYdTv8F89y4pY5OLPfY8sckU0cawd3l9A2W/a7XoGMPEvOtuW2exzDTf0XdbHyd+ON/MsbfqBR/JSyr5UzlidSaN+GUgrVi2hpSxI3WrsDQ3V3JcbLZHtuaY1uMLtbcBxXMbTz89h3v2TIgQAwtffueRXWSbWij1e9rQOvFI/bcLxYile29C2JxF+wUkiL5M/ZG2pZHsY5hawWXOdYvTQC+Kxe1pvIJ6tatt2fFO4GIOaWEhwcK0/wDAua21LvzOPTw/gtfoUZPVN+yZkdbko6an6sz0J1IpeyPIWNpBTqRSAsjpKAnEJaTsdjaRSdSKSFY2klKTdSUmFkdJKUu6k3UWOxlIUm4kRuCyZCdSN1czlY1FJ26ikwsak3U6kEIHYzdRupyWkBYykoanFKAgLGbqXdT6TgEhbjku0uPuStkGgeNf4gtnHwW0HVroQptr7PE0ZbXiAJYb4OpS4gO4AeIaAR5gUV5XrOBwnvXhnquj6hZIbPVEORs5s7mku3a0NcwulwY2sa1jeDQAFhwO3TR9QtzB191htuqNuKV2apZQ3uWiv7QxHSxVG7ce6Omvqw11aEjmmRw7zK6K3ivJYBWo0UDqeWT7Cz2PsPDnhwcHtLSbHD7Q+is4vaPbOM4Rl8pbZIbLCxzCTx8Qb59V6LJjFx4KvNgTgaTW0agPY11e/FdVkoh2U3Zm4Eb2xy5M24JpB3j9zRoNUAPz9SuVc6ySeJNldZt15jxWsJBfK/xUKFDXTy4LlaXqOg4qxyyP1f7HmOvZryxxr0X7jEUnbqWlvWYNjKRSkpKGp2FkYCSlNuJdxKxbiGkUpd1JuosNxGAilKAntaENi3EAanbisiFKGKG8ZAIShW7QobmMrbqUhT7iQx+SdnPayCkUpDGkIpSsOSMhJSfSSkCsbuo3U6kIHY2kUnICLCwShK1qeI0rEMpVmcXfxH9VfbGs7v27722AQ6iL10AHBY/WucC/Jt9D4zv8DpWc1YxMzdITasKrI08uK8oetO12ZtAO08lqwyVryK81x9omM62uj2d2hbwJ4qLROMjs3Gxopty2+axMLarTzFeytf1kOFj8UjqmYXasEva2tGtv3tYBxz0XT7bIeWuHSis7u/Jex6ZkrSwr+cniOrY29XNv+cGP3J6I7ryK1+78koiWh3TN7X3MjuvJKIStf4cJDjI7wdlmV3KVzVomFNONafcE8TMshJS0vgknwKfcRHtyM+k9jVbOGmmIhPemLY0RE0md4pXtURjR5E7Q0uKRO7o9EJ8C5L7QEppSCNBYuG4t0VJAo3MVpzFGWKakcnAqOam0rncpPh1PeQ7bKdJQ1XBjqRuMl3ECxsotjKmbCrzMZSiBQeU6rCUmwqRsStiJSNhXN5CaxlMRLzHbuQ1+RI9hsF5IcOB4DT8F6dt/NZiYzZzUj8hzo8WEGjLumnvJ5MbwvmfxXkbwRfAa8BwHosvW6iM1tRraHTyg3J8Ghh7bmj0Dt4dHi/8AutaDtK0/3kdebDY/A/quWBUzD5rMeKL9DVWWS8M6SbacL/mr1abWbLmtB8LrHobVDdHX6IEXqfQKPwyJ9+Rpw7ZLeD3j0tWG7dlqw51DqeSx2Y2uuiuFgI3Rw5nyU1pY+oPUTrg9Rwmh7GuYS5rgCOZ91P3HkuG7NOllmx4xNIwNy8d7Yw6oy0SNJLhzoAldvmbUccnI3GNdC2d4ZR3XAA6+uq0FrI46g1Rl/wBOy5nKUeWP+H8k0wqT+smBoe9kjGuBc0kNcCA4tJ8JJ4gjgr0DWvj70Ed2X92HHwgvq6F8TWqsR1UH6lWeiyw+qLMssTSFoTyRN4vb6DUqt8VCfmr1C6rMji8E/Yq7qCKVtr4jwe38a/NOdGCprImc3ikvJQ3kneqeSIKrJGuipnNpok7xNIBUNJwcVKiO4HRJhjTy5FpqxUmMDQhSd0ehSpdxe5Ltv2J6TXBWpYTZ00tQFq5Rlas6SVOiExIMSlKRxU7ZEh3FJHHajc5KyWlJ3REusxgrMeI3noudzu0G4KYRVav4/wCH9VhZHaR50BJ8yVTyZ9rov4tM5K2d48xM4vA+qqS7ThHCz50AuDdtN7tS60gznLj3mWVpI+p3+TlRtxTlD5cmOBzTyD22HaeZaPdYe3MuQY4kErmOfK6NrWbrRuNjJfrV3b4xx6rKfnOdiSRnh8RC8jrqAP8AKrHaogQ4gIuxmO9y+Jl/8izs2oyNyV8Gro9JiSTrkp9r8zv8TBnZwxYnYsrRXgdY3XVw1r6hcVLK5xsuJ9a/kuh2bkBhdFIN6GUFsjfLkR5hZO1dlOx37h1a4b0Tx9mSPkR59QuGOfO1ks+OnaKQapom6qINPVSxkqwiuXBF5n6KVsHm4+5/knROdXL8E+yu0UiI6OADWgle3qdOnM+yUAniaV3ZGB38oiZQJBc+Rx8McbRbnuPIAJyairY0m+EXuy8Bi3sx2gj3ooG/fnePqGtu/VXH7RLR3bNXH7TjxJPElQ7Ry2u3WRAiCFu5ACKLh80jh95x19KCrwtrXmsuc3KTZ6PR6btQ+7Om2lkbmLFHxecZziedSZMwCi7Qbc3IceEaNDsh+nN2+Wg/gaTdoNBfFZ0bgYVgdTvy/m9YHaU2Yh0iLv8AHI4rvj+qKKGq/t393+5DLtZx1tR/1k881n7qcAtC2ZFGlHnuHNaWLtgtGjiPLkueBQZFLcxOKfk7LZe2RN4XU2ThXJ/p5+S0SFwQd7fmut7MbVEzhBKR3hFRvPz+R/e/NWMeevJQz6T1iXu7tIYj0XSxbOHROk2cDyUviEVvh2cuYStPBxmHjxVp2zSofhnNNqUsu5UmEcW12TyYgvQaIS9+eiFScHZeU1XguvxxSzMnE6LWc9ROK6xk0V5RTOclgIUDgV0ckYKpy4oKtQze5WlifoYpC53tRtQRtMLT43Dx18renqfyXQ9ocpuJCZDW8fDG0/M8jT2HH2XlmVkGQlziSSbJPEnmVDUanbGo+Wd9Jpt0t0vCLjsgvaNeGiY1QYh0I6KdizVya1E0ZU7SoApGlTTAuEVjyO/3+M0etk/ktbtY4iPDINHusn/rlZmaKw4qNOmzHEX0jbu/m4K72ucRBhHnuZQPtK1Z2R25P7mppuEjndw3ZXQbPiZlMGHM4MJN4szuEUx4Nd+47h/4FhRuJ4q0yQcFxZdWKMotP1M3M2bJC90UjNySNxa9p5H9Od+ahMB+6PxK7qbFk2jFbQTmY0Wj6sZMANBjz/7gJpp58FyjX6efPSiD5q9hkpr7mNnxPFKmRQucOQ/NSalOtK1WUqOApbQ6/qujfEMWL4Zv99M1r813No+0zHB6cHO9h1TeyeA1wny3gFuHFJJC14tkmS2Nz2gj5gA2yFTicXeNxLnPJe9ztXOc42SfMlUdTkt7V4NXpuBSlvfoOAUjUy0jjofQqqbbNzbDmiZwJP7OHAjofN/Y4iB+JKx+0I8UX/DRfzWptyMnNlHLvYB6iPEjb+Y+iodoWWyGTo18DvVptv8AykK1DicTD1CvCYZCROJTCVoGUIUwnUeqVxULjqPVJsC+Et1qNCNQRoQUxpT1ID1PsR2kGUzupCBkxDX/AHrPvjz6rp6C8Jxct8EjZozuvYbaeR6g+R4L2HY2125MLZmaBw8TebHjRzT7qDOGSFcmoYwmPxQUzvk9s6XJyKzsIIVwFInuYUjCM4SGceSyjIU0vK0O0Z/dNR84TO/Cy7Ky+0m0TBA9wNPd4Gdd53P2Fn2TcFFWxRk5SSXqcj222z8TOWtP7KEmNlcCb8bvcivQLngmjUqw2NZM5OUrNyEdsUhcTifMKdpUW5RB6cU0O8RHkULgZYD+HmpA9U2v4LQ2Ph/ESsivdDjcjz9mOJo3pHnyDQSnurkdFrtBoMXH5x4zZpB0knd3n+TulsdpYrx8KuDfi2a+RhP+pczmZ3xOXJNRa2WQmNp+WIeGNvswNHsup7QP/seOfu5OQ3/FDEf9KotfKaum9LOdLEx7VM2YHipQxrua5GlSfg2exuY9oyWhxBGG+RrhoQY5ongg9RRU/aTZwyWuzYmhszRvZ0LRQcP/AJLB0+8OR1VPs3CWvnHHewM4D17hzh/lWjs/OMZZK006gRzFEagjmCNCF3x2la8lLPi3tpnHUtDY+zXZD90ENY0F80rtGRRji5x5aLfyuywyH97ibjIHW7IbI8NZhULcXE8Y+Jafbko86WMRfC49/DAhz5HDdflyj53jiGD5We51qrEs9qo+TOhpm50/QkxZRL8R3ILcSDAyo8dpFFxfuB8r/wB53nwAA5LLazl5K/sSUCHLA1DcR4vmS6WNv81nd6VUyeTc0aUU6H7qR8eh9CkLieaCdD6LmW34NvaktZuZ/wAU4DoKaB/JRiDvmSY13LIDPjjrLHxYP4mkj2CNtyf2rKBH/qpCPME2FnSzlj2SNJBaDukcQ4EOBHn4VZatGTt3Y6MS0Erou0eG2eL+scdo3SR8dE3/AGEp/wBqG8o3m/4Ta5cvpXMeRTRkTg4umOJVcu1Hqlldp5uP05qDf8VdESkQovNk1VljljMm1Pqr8E6cZgXS21t9jNu/CymJ5/YzEC+TJOAPoeB9lixutMnxr1U/IpK1R7O3IBT+96ari+zO2O9gDSbyIvA4c3D5Xe409Qt/vrbYJa9urgeFLP12tjh+WH1FNJ3yazM3TUEH0SLG75330LF+O1H6iXBSQGoQve2ZA4MXDf0h5Hjjh5NaZD6uND6NP4oQuGpk+2y1pIruo5GAK/E3l14HoUIWZE2GSPi0pZeS4h1oQnk4Ggcefut/HJhxqH97mgtLvuYbXU5oPV7m0f3WkfMhCr5G6o7YUnIoYzN+fTg1dJnS95g/wZsNf/uCa/8AIEIUJeC/h/2c9uqdjEIVcvxR0XZNxM+596DMb+OJKjYbmy/Dw8HzujiaTwBcatCF1g/lZwzupv8AH/TWk2h8SH4kY7rEx2vlEQ0M72SNYXyuH2jrdHTpwVLa2zWshZPHZeTNvxk6GJgb47PA24CvPyQhdlxiM9trPSM/YT/7NmH5u4Zfp8VCqjXWlQq+Tya+l8P8kgQ86H0P5JEKBaNvb0oOTOCNd9jr/iiY7/UsnOHhscW+Ieo1QhW14MyPgl2JtJ2NJ3kdUR4mPG9G9jh4mPbzaeib2x2A2JrMvHAZiz91vQlxJxpZIxIGtJ+0wg6dOHRIhc23GSa9ytqIJxs5V7+J5NsD15qrvUL5oQrUjNGRuVqN6RCUWMvY86043WEqFYiRJMV74XiWJ1PB4HVpHQ+S73Yu1W5LDIG05tiRp1DTXI8whCzupYoOG+uUcsiIH7TaDWunkhCFhUjlR//Z",
    answers: {
      "xj352vofupe1dqz9emx13r": 'optionOne',
      "vthrdm985a262al8qx3do": 'optionTwo',
      "6ni6ok3ym7mf1p33lnez": 'optionTwo'
    },
    questions: ['6ni6ok3ym7mf1p33lnez', 'xj352vofupe1dqz9emx13r'],
  }
}

let questions = {
  "8xf0y6ziyjabvozdd253nd": {
    id: '8xf0y6ziyjabvozdd253nd',
    author: 'sarahedo',
    timestamp: 1467166872634,
    optionOne: {
      votes: ['sarahedo'],
      text: 'have horrible short term memory',
    },
    optionTwo: {
      votes: [],
      text: 'have horrible long term memory'
    }
  },
  "6ni6ok3ym7mf1p33lnez": {
    id: '6ni6ok3ym7mf1p33lnez',
    author: 'johndoe',
    timestamp: 1468479767190,
    optionOne: {
      votes: [],
      text: 'become a superhero',
    },
    optionTwo: {
      votes: ['johndoe', 'sarahedo'],
      text: 'become a supervillain'
    }
  },
  "am8ehyc8byjqgar0jgpub9": {
    id: 'am8ehyc8byjqgar0jgpub9',
    author: 'sarahedo',
    timestamp: 1488579767190,
    optionOne: {
      votes: [],
      text: 'be telekinetic',
    },
    optionTwo: {
      votes: ['sarahedo'],
      text: 'be telepathic'
    }
  },
  "loxhs1bqm25b708cmbf3g": {
    id: 'loxhs1bqm25b708cmbf3g',
    author: 'tylermcginnis',
    timestamp: 1482579767190,
    optionOne: {
      votes: [],
      text: 'be a front-end developer',
    },
    optionTwo: {
      votes: ['sarahedo'],
      text: 'be a back-end developer'
    }
  },
  "vthrdm985a262al8qx3do": {
    id: 'vthrdm985a262al8qx3do',
    author: 'tylermcginnis',
    timestamp: 1489579767190,
    optionOne: {
      votes: ['tylermcginnis'],
      text: 'find $50 yourself',
    },
    optionTwo: {
      votes: ['johndoe'],
      text: 'have your best friend find $500'
    }
  },
  "xj352vofupe1dqz9emx13r": {
    id: 'xj352vofupe1dqz9emx13r',
    author: 'johndoe',
    timestamp: 1493579767190,
    optionOne: {
      votes: ['johndoe'],
      text: 'write JavaScript',
    },
    optionTwo: {
      votes: ['tylermcginnis'],
      text: 'write Swift'
    }
  },
}

function generateUID () {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
}

export function _getUsers () {
  return new Promise((res, rej) => {
    setTimeout(() => res({...users}), 1000)
  })
}

export function _getQuestions () {
  return new Promise((res, rej) => {
    setTimeout(() => res({...questions}), 1000)
  })
}

export function formatQuestion ({ optionOneText, optionTwoText, author }) {
  return {
    id: generateUID(),
    timestamp: Date.now(),
    author,
    optionOne: {
      votes: [],
      text: optionOneText,
    },
    optionTwo: {
      votes: [],
      text: optionTwoText,
    }
  }
}

export function _saveQuestion (question) {
  return new Promise((res, rej) => {
    const authedUser = question.author;
    const formattedQuestion = formatQuestion(question);

    setTimeout(() => {
      questions = {
        ...questions,
        [formattedQuestion.id]: formattedQuestion
      }
      
      users = {
        ...users,
        [authedUser]: {
          ...users[authedUser],
          questions: users[authedUser].questions.concat([formattedQuestion.id])
        }
      }

      res(formattedQuestion)
    }, 1000)
  })
}

export function _saveQuestionAnswer ({ authedUser, qid, answer }) {
  console.log("SaveQuestionAnswer --- The authedUser: ", authedUser)
  console.log("The qid: ", qid)
  console.log("The answer: ", answer)
  return new Promise((res, rej) => {
    setTimeout(() => {
      users = {
        ...users,
        [authedUser]: {
          ...users[authedUser],
          answers: {
            ...users[authedUser].answers,
            [qid]: answer
          }
        }
      }

      questions = {
        ...questions,
        [qid]: {
          ...questions[qid],
          [answer]: {
            ...questions[qid][answer],
            votes: questions[qid][answer].votes.concat([authedUser])
          }
        }
      }

      res()
    }, 500)
  })
}
